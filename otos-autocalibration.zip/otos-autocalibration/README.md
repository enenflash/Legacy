# legacy-template
Legacy (RCJ Australian lightweight team)
template repo for hardware classes

Convention:
* all angles in radians
* all distance measurements in cm
* origin (0, 0) is centre of field

Note: 
* run "pio pkg update" to update all packages (SparkFun library requires latest version)
* ultrasonic classes have not been tested