#include <iostream>
#include <cmath>
#include <Arduino.h>
#include <Wire.h>
#include <Adafruit_Sensor.h>
#include <Adafruit_BNO055.h>
#include <SoftwareSerial.h>

#include "pins.h"
#include "vector.hpp"
#include "motor_controller.hpp"
#include "position_system.hpp"
#include "ir_sensor.hpp"
#include "line_sensor.hpp"
#include "dribbler.hpp"
#include "bluetooth.hpp"
#include "pid.hpp"

#include <SPI.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

bool check_robot_start();

IRSensor ir_sensor;
LineSensor line_sensor;
PositionSystem pos_sys;

MotorController motor_ctrl(20);
DribblerMotor dribbler(DR_DIR, DR_PWM);
Adafruit_SSD1306 display(128, 32, &Wire, -1);

PID movement_pid;

bool robot_start = false;
bool calibration_finished = false;

float mv_angle = 0;
float speed = 0;
float rotation = 0;
bool dribbler_on = false;
int movement_speeds[10] = {20, 100, 30, 90, 40, 80, 50, 70, 60};

int loop_index;
float sum_line_distance, actual_distance, drift, linear_scalar;
Vector start_pos, end_pos;

void setup() {
  // put your setup code here, to run once:
  Serial.begin(115200);
  Serial2.begin(921600); // Line Sensor
  Serial6.begin(921600); // IR Sensor

  pinMode(DEBUG_LED, OUTPUT);

  // Drive motors
  pinMode(TL_PWM, OUTPUT); pinMode(TR_PWM, OUTPUT); pinMode(BL_PWM, OUTPUT); pinMode(BR_PWM, OUTPUT);
  analogWriteFrequency(TL_PWM, 20000); analogWriteFrequency(TR_PWM, 20000);
  analogWriteFrequency(BL_PWM, 20000); analogWriteFrequency(BR_PWM, 20000);
  pinMode(TL_DIR, OUTPUT); pinMode(TR_DIR, OUTPUT); pinMode(BL_DIR, OUTPUT); pinMode(BR_DIR, OUTPUT);

  motor_ctrl.stop_motors();

  // Ultrasonics (default no power)
  pinMode(UL_TRIG, OUTPUT);
  pinMode(UR_TRIG, OUTPUT);
  pinMode(UB_TRIG, OUTPUT);
  pinMode(UL_ECHO, INPUT);
  pinMode(UR_ECHO, INPUT);
  pinMode(UB_ECHO, INPUT);
  pinMode(BTN_1, INPUT_PULLDOWN);
  pinMode(BTN_2, INPUT_PULLDOWN);
  pinMode(BTN_3, INPUT_PULLDOWN);
  pinMode(BTN_4, INPUT_PULLDOWN);
  pinMode(BTN_5, INPUT_PULLDOWN);

  pinMode(DR_PWM, OUTPUT);
  pinMode(DR_DIR, OUTPUT);

  pos_sys.setup(); // bno055

  // Display Setup
  display.begin(SSD1306_SWITCHCAPVCC, 0x3C);
  display.setRotation(2);     
  display.setTextColor(SSD1306_WHITE);
  display.cp437(true);  

  // Displaying Ready and compile date/time
  display.clearDisplay();
  display.setTextSize(2);
  display.setCursor(0, 0);   
  display.println("Ready");

  display.setTextSize(1);
  display.setCursor(0, 20);
  display.print(__DATE__); display.print(" "); display.println(__TIME__);
  display.display();

  Serial.println("Awaiting button press");
}

void loop() {
  /* ----------------------------- UPDATE SENSORS ----------------------------- */

  pos_sys.update();
  ir_sensor.update();
  line_sensor.update();

  float heading = pos_sys.get_heading();
  Vector posv = pos_sys.get_posv();

  // angle correction
  float ball_angle = fmodf(PI + ir_sensor.get_angle() + heading, 2 * PI) - PI;
  float line_angle = fmodf(PI + line_sensor.get_angle() + heading, 2 * PI) - PI;

  // check for button press
  if (!robot_start) {
    speed = 0;
    dribbler_on = false;
    robot_start = check_robot_start();
    start_pos = pos_sys.get_posv();
  }

  /* ------------------------------ OUTPUT VALUES ----------------------------- */
  
  // While still moving up and down
  while (loop_index < 10 && !calibration_finished) {
    speed = movement_speeds[loop_index]; // varies the speed
    if (loop_index % 2 == 0) { // alternates between moving forward and backward
      mv_angle = PI/2-heading;
    }
    else {
      mv_angle = 3*PI/2-heading;
    }
    rotation = -heading;
    while (rotation > PI) rotation -= 2*PI;
    while (rotation < -PI) rotation += 2*PI;

    if (line_sensor.get_distance() != 0 && ( // if reaches line sensor 
      line_sensor.get_angle() < PI && loop_index % 2 == 0 ||
      line_sensor.get_angle() >= PI and loop_index % 2 != 0
    )) {
      loop_index += 1;
      sum_line_distance += (11-line_sensor.get_distance()/10); 
      // sums the extra distance the robot travelled due to the delay in sensing the line
    }
  }
  
  // runs once when the robot is done moving up and down
  if (loop_index >= 10) {
    calibration_finished = true;
    loop_index = 0;
    end_pos = pos_sys.get_posv();
    actual_distance = 1610 + sum_line_distance;
    drift = end_pos.j-start_pos.j; // only does horizontal
    linear_scalar = actual_distance / (actual_distance - drift); // actual distance / measured distance
  }
  
  if (calibration_finished) {
    speed = 0;
    display.clearDisplay();
    display.setCursor(0, 0);
    display.print("scalar: ");
    display.print(linear_scalar);
    display.display();
  }

  /* ------------------------------- RUN MOTORS ------------------------------- */

  if (dribbler_on) {
    dribbler.run();
  }
  else {
    dribbler.stop();
  }

  motor_ctrl.run_motors(speed, mv_angle, rotation);
  digitalWrite(DEBUG_LED, HIGH);
}

bool check_robot_start() {
  if (digitalRead(BTN_1) == HIGH || digitalRead(BTN_2) == HIGH || digitalRead(BTN_3) == HIGH ||
      digitalRead(BTN_4) == HIGH || digitalRead(BTN_5) == HIGH) {
    return true;
  }
  return false;
}